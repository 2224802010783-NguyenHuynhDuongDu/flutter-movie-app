import 'package:flutter/material.dart';
import '../models/movie.dart';

class DetailScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final Movie movie = ModalRoute.of(context)!.settings.arguments as Movie;

    return Scaffold(
      appBar: AppBar(title: Text(movie.title)),
      body: Column(
        children: [
          Hero(
            tag: "movie_${movie.title}",
            child: Image.network(
              movie.image,
              height: 300,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ),

          const SizedBox(height: 20),

          Text(
            movie.title,
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          ),

          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              movie.description,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16),
            ),
          ),

          ElevatedButton.icon(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(Icons.arrow_back),
            label: const Text("Quay lại"),
          ),
        ],
      ),
    );
  }
}
